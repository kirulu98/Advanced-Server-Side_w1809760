<?php
$cw1=$_POST['cw1'];
$cw2=$_POST['cw2'];
$mark=($cw1 * 0.4) + ($cw2 * 0.6);
echo '<body>'.$mark.'</body>';
